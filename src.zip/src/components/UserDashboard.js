import React, { useState, useEffect } from 'react';
import { app } from './firebaseConfig';
import { getDatabase, ref, push, onValue, remove, update } from 'firebase/database';
import './UserDashboard.css';
import UserProfile from './UserProfile';
import NavigationBar from './NavigationBar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes } from '@fortawesome/free-solid-svg-icons';
import { format } from 'date-fns';


function UserDashboard({ email, onLogout, profileImageUrl, fullName }) {
    const [selectedService, setSelectedService] = useState('');
    const [selectedEmployee, setSelectedEmployee] = useState('');
    const [transactions, setTransactions] = useState([]);
    const [showTransactions, setShowTransactions] = useState(false);
    const [showProfile, setShowProfile] = useState(false);
    const [showNavigationBar, setShowNavigationBar] = useState(false);
    const [userDetails, setUserDetails] = useState(null);
    const [iconSpin, setIconSpin] = useState(false);
    const [isHovering, setIsHovering] = useState(false);
    const [timeError, setTimeError] = useState('');
    const [selectedDate, setSelectedDate] = useState(''); // State for selected date
    const [selectedTime, setSelectedTime] = useState(''); // State for selected time
    const [editTransaction, setEditTransaction] = useState(null);
    const [editedDateTime, setEditedDateTime] = useState('');
    
    // Prices associated with each service ID
    const servicePrices = {
        1: '$30',
        2: '$25',
        3: '$35',
    };

    const db = getDatabase(app);

    const services = [
        { id: 1, name: 'Haircut' },
        { id: 2, name: 'Manicure' },
        { id: 3, name: 'Pedicure' },
    ];

    const employees = ['Employee 1', 'Employee 2', 'Employee 3'];

    useEffect(() => {
        const transactionsRef = ref(db, 'transactions');
        onValue(transactionsRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const userTransactions = Object.values(data).filter(transaction => transaction.userEmail === email);
                setTransactions(userTransactions);
            } else {
                setTransactions([]);
            }
        });

        const userRef = ref(db, 'users');
        onValue(userRef, (snapshot) => {
            const userData = snapshot.val();
            if (userData && userData[email]) {
                setUserDetails(userData[email]);
            } else {
                setUserDetails(null);
            }
        });
    }, [db, email]);

    const handleTransactionSubmission = () => {
        if (!selectedService || !selectedEmployee || !selectedDate || !selectedTime) {
            alert('Please select service, employee, date, and time.');
            return;
        }
    
        const selectedDateTime = new Date(selectedDate + 'T' + selectedTime);
        
        // Check if the selected time is between 9am and 7pm
        const selectedHours = selectedDateTime.getHours();
        if (selectedHours < 9 || selectedHours >= 19) {
            alert('Please select a time between 9am and 7pm.');
            return;
        }
    
        // Check if the selected date and time conflicts with existing transactions
        const isConflict = transactions.some(transaction => {
            const transactionDate = new Date(transaction.appointmentDateTime);
            return transactionDate.getTime() === selectedDateTime.getTime();
        });
    
        if (isConflict) {
            alert('This date and time slot is already booked. Please select another one.');
            return;
        }
    
        const transactionData = {
            userEmail: email,
            service: selectedService,
            employee: selectedEmployee,
            appointmentDateTime: selectedDateTime.toISOString(), // Convert date to ISO string for storing in database
            status: 'pending',
        };
    
        push(ref(db, 'transactions'), transactionData)
            .then(() => {
                console.log('Transaction submitted successfully.');
                setSelectedService('');
                setSelectedEmployee('');
                setSelectedDate(''); // Reset date and time after submission
                setSelectedTime('');
            })
            .catch((error) => {
                console.error('Error submitting transaction:', error);
                alert('An error occurred while submitting transaction. Please try again.');
            });
    };
    
    const handleCancelTransaction = (transaction) => {
        const transactionRef = ref(db, 'transactions');
        let transactionKey = null;

        onValue(transactionRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const keys = Object.keys(data);
                const foundKey = keys.find((key) => {
                    const t = data[key];
                    return (
                        t.userEmail === transaction.userEmail &&
                        t.service === transaction.service &&
                        t.employee === transaction.employee &&
                        t.status === transaction.status
                    );
                });
                if (foundKey) {
                    transactionKey = foundKey;
                }
            }
        });

        if (!transactionKey) {
            console.error('Transaction key not found.');
            return;
        }

        remove(ref(db, `transactions/${transactionKey}`))
            .then(() => {
                console.log('Transaction canceled successfully.');
            })
            .catch((error) => {
                console.error('Error canceling transaction:', error);
                alert('An error occurred while canceling transaction. Please try again.');
            });
    };

    const handleEditTransaction = (transaction) => {
        if (transaction.status !== 'pending') {
            alert('You can only edit transactions with pending status.');
            return;
        }
    
        setEditTransaction(transaction);
        setEditedDateTime(transaction.appointmentDateTime);
        setSelectedService(transaction.service);
        setSelectedEmployee(transaction.employee);
    };
    
    
    const handleSaveEditedTransaction = () => {
        if (!editedDateTime) {
            alert('Please enter the new appointment date and time.');
            return;
        }
    
        const editedDateTimeObj = new Date(editedDateTime);
        const now = new Date();
    
        if (editedDateTimeObj < now) {
            alert('You cannot set a time that has already passed.');
            return;
        }
    
        const transactionRef = ref(db, 'transactions');
        let transactionKey = null;
    
        onValue(transactionRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const keys = Object.keys(data);
                const foundKey = keys.find((key) => {
                    const t = data[key];
                    return (
                        t.userEmail === editTransaction.userEmail &&
                        t.service === editTransaction.service &&
                        t.employee === editTransaction.employee &&
                        t.status === editTransaction.status
                    );
                });
                if (foundKey) {
                    transactionKey = foundKey;
                }
            }
        });
    
        if (!transactionKey) {
            console.error('Transaction key not found.');
            return;
        }
    
        const updates = {};
        updates[`transactions/${transactionKey}/appointmentDateTime`] = editedDateTime;
        updates[`transactions/${transactionKey}/status`] = 'pending';
    
        update(ref(db), updates)
            .then(() => {
                console.log('Transaction edited successfully.');
                setEditTransaction(null);
                setEditedDateTime('');
            })
            .catch((error) => {
                console.error('Error editing transaction:', error);
                alert('An error occurred while editing transaction. Please try again.');
            });
    };
    
   
    
    const handleShowTransactions = () => {
        setShowTransactions(true);
        setShowProfile(false);
    };

    const handleHideTransactions = () => {
        setShowTransactions(false);
    };

    const handleShowProfile = () => {
        setShowProfile(true);
        setShowTransactions(false);
    };

    const handleShowNavigationBar = () => {
        setShowNavigationBar(true);
    };

    const handleHideNavigationBar = () => {
        setShowNavigationBar(false);
    };

    const handleNavigateToLogin = () => {
        window.location.reload();
    };

    const handleTimeChange = (e) => {
        const selectedTime = e.target.value;
        const [hours, minutes] = selectedTime.split(':').map(Number);
        if (hours < 9 || hours >= 19) {
            setTimeError('Please select a time between 9am and 7pm.');
        } else {
            setTimeError('');
            setSelectedTime(selectedTime);
        }
    };

    return (
        <div className="user-dashboard-container">
            {showNavigationBar && (
                <NavigationBar
                    onShowTransactions={handleShowTransactions}
                    onShowProfile={handleShowProfile}
                    onLogout={handleNavigateToLogin}
                    profileImage={profileImageUrl} // Pass profile image URL as prop
                    Name={fullName} // Pass full name as prop
                />
            )}
            <div className="dashboard-content">
                <h2>User Dashboard</h2>
                {!showTransactions && !showProfile && (
                    <div className="selection-container">
                        <div className="service-selection">
                            <label htmlFor="service-select">Select Service:</label>
                            <select
                                id="service-select"
                                value={selectedService}
                                onChange={(e) => setSelectedService(e.target.value)}
                            >
                                <option value="">Select</option>
                                {services.map((service) => (
    <option key={service.id} value={service.name}>
        {service.name} - {servicePrices[service.id]}
    </option>
))}

                            </select>
                        </div>
                        <div className="employee-selection">
                            <label htmlFor="employee-select">Select Employee:</label>
                            <select
                                id="employee-select"
                                value={selectedEmployee}
                                onChange={(e) => setSelectedEmployee(e.target.value)}
                            >
                                <option value="">Select</option>
                                {employees.map((employee, index) => (
                                    <option key={index} value={employee}>
                                        {employee}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className="date-time-selection">
                            <label htmlFor="date-select">Select Date:</label>
                            <input
                                type="date"
                                id="date-select"
                                min={new Date().toISOString().split('T')[0]} // Set min attribute to current date
                                value={selectedDate}
                                onChange={(e) => setSelectedDate(e.target.value)}
                            />
                        </div>
                        <div className="date-time-selection">
                            <label htmlFor="time-select">Select Time:</label>
                            <input
                                type="time"
                                id="time-select"
                                min="09:00"
                                max="19:00"
                                value={selectedTime}
                                onChange={handleTimeChange}
                            />
                            {timeError && <p className="error-message">{timeError}</p>}
                        </div>
                        <button className="submit-button" onClick={handleTransactionSubmission}>
                            Submit
                        </button>
                    </div>
                )}
               {showTransactions && (
    <div>
        <h3>Your Transactions</h3>
        <ul>
            <div className="transactions-container">
            {transactions.map((transaction, index) => (
    <li key={index}>
        <p>Service: {transaction.service}</p>
        <p>Employee: {transaction.employee}</p>
        <p>Status: {transaction.status}</p>
        <p>Date and Time: {format(new Date(transaction.appointmentDateTime), 'MMMM dd, yyyy hh:mm a')}</p>
        {transaction.status === 'pending' ? (
            // Render edit button for pending transactions
            editTransaction === transaction ? (
                <>
                    <input
                        type="datetime-local"
                        value={editedDateTime}
                        min={new Date().toISOString().split('T')[0] + 'T00:00'} // Set min attribute to current date and time
                        onChange={(e) => setEditedDateTime(e.target.value)}
                    />
                    <select
                        value={selectedService}
                        onChange={(e) => setSelectedService(e.target.value)}
                    >
                        <option value="">Select</option>
                        {services.map((service) => (
                            <option key={service.id} value={service.name}>
                                {service.name} - {servicePrices[service.id]}
                            </option>
                        ))}
                    </select>
                    <select
                        value={selectedEmployee}
                        onChange={(e) => setSelectedEmployee(e.target.value)}
                    >
                        <option value="">Select</option>
                        {employees.map((employee, index) => (
                            <option key={index} value={employee}>
                                {employee}
                            </option>
                        ))}
                    </select>
                    <button
                        className="save-button"
                        onClick={handleSaveEditedTransaction}
                    >
                        Save
                    </button>
                </>
            ) : (
                <button
                    className="edit-button"
                    onClick={() => handleEditTransaction(transaction)}
                >
                    Edit
                </button>
            )
        ) : (
            // Hide or remove the cancel button for accepted transactions
            transaction.status === 'accepted' ? null : (
                <button
                    className="decline-button"
                    onClick={() => handleCancelTransaction(transaction)}
                >
                    Cancel
                </button>
            )
        )}
    </li>
))}
            </div>
        </ul>
        <button className="logout-button" onClick={handleHideTransactions}>
            Return
        </button>
    </div>
)}
                {showProfile && <UserProfile email={email} userDetails={userDetails} />}
            </div>
            <div className="navigation-control" style={{ position: 'fixed', top: '10px', left: '10px' }}>
                {showNavigationBar ? (
                    <button
                        className={`navigation-button ${iconSpin || isHovering ? 'spin' : ''}`}
                        onMouseEnter={() => setIsHovering(true)} // Set hover state to true on mouse enter
                        onMouseLeave={() => setIsHovering(false)} // Set hover state to false on mouse leave
                        onClick={handleHideNavigationBar}
                    >
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                ) : (
                    <button
                        className={`navigation-button ${iconSpin || isHovering ? 'spin' : ''}`}
                        onMouseEnter={() => setIsHovering(true)} // Set hover state to true on mouse enter
                        onMouseLeave={() => setIsHovering(false)} // Set hover state to false on mouse leave
                        onClick={handleShowNavigationBar}
                    >
                        <FontAwesomeIcon icon={faBars} />
                    </button>
                )}
            </div>
        </div>
    );
}

export default UserDashboard;