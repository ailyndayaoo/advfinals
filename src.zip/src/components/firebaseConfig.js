import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage"; // Import getStorage function



// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAfnIMDnwu8KR_X6b7yfpz_CWH-cpDW-0E",
  authDomain: "advfinals.firebaseapp.com",
  databaseURL: "https://advfinals-default-rtdb.firebaseio.com/",
  projectId: "advfinals",
  storageBucket: "advfinals.appspot.com",
  messagingSenderId: "485483092395",
  appId: "1:485483092395:web:44e4ad86e662f2631c9aee",
  measurementId: "G-VPJJET5P4M"
};
// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Get Firebase services
const db = getDatabase(app);
const auth = getAuth(app);
const storage = getStorage(app); // Initialize Firebase Storage
//const storageRef = storage.ref(); // Get reference to the root of the Firebase Storage bucket

// Export Firebase services
export { app, db, auth, storage };
